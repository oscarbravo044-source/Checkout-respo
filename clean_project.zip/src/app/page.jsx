export default function Page() {
  return (
    <main style={{ padding: 40 }}>
      <h1>Checkout Page</h1>
      <p>Your clean project is ready. Add your custom UI here.</p>
    </main>
  );
}
